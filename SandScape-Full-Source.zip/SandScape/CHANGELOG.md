# Changelog

## 1.0.0 — 2026-07-13

- Initial functional SandScape release
- Live four-material sand and trapped-air simulation
- Tilt, shake, touch and drag interactions
- Four palettes and two frame shapes
- Adaptive performance tiering
- Offline PWA support
- Capacitor 8.4.1 Android and iOS native projects
- Native app icons, splash screens, tests and build scripts
