# SandScape

SandScape is a working gravity-responsive moving-sand art application. It runs immediately as an installable PWA and is packaged for native iOS/Android deployment through Capacitor.

## What is implemented

- Live multi-material sand simulation with four density/color layers
- Implicit viscous liquid and dynamic air pockets
- Air barrier that creates narrow sand waterfalls
- Density sorting and angle-of-repose style settling
- Bubble/foam interface rendering
- Device orientation gravity with low-pass smoothing
- Shake-to-flip on supported mobile browsers/native wrappers
- Tap disturbance and drag-to-tilt fallback
- Four palettes: Ocean, Desert, Aurum, Orchid
- Circular and rectangular glass frames
- Adjustable flow and air levels
- Screenshot export
- Offline installation as a PWA
- Adaptive simulation resolution for mobile performance

## Run it now — zero install

### Windows PowerShell

```powershell
Set-ExecutionPolicy -Scope Process Bypass -Force
& .\scripts\Start-SandScape.ps1 -OpenBrowser
```

Then open the displayed URL on a phone connected to the same network, using the computer's LAN IP instead of `localhost`.

### Any system with Python 3

```bash
cd www
python3 -m http.server 4173
```

Open `http://localhost:4173`.

## Mobile controls

- **Tilt:** press **Enable tilt**, grant motion access, then rotate the phone.
- **Tap:** locally disturbs the sand.
- **Long press:** opens palettes and controls.
- **Shake:** flips the frame after motion permission is granted.
- **Desktop fallback:** drag in the frame or use arrow keys. Press `F` to flip, `P` for controls, and `D` for performance diagnostics.

## Generate native mobile projects

### Android

```powershell
& .\scripts\Build-Mobile.ps1 -Platform Android -OpenIDE
```

Requires Node.js 22+, Android Studio 2025.2.1 or newer, and an Android SDK (API 24+). Android Studio supplies the supported JDK.

### iOS

Run this on macOS with Xcode 26 or newer:

```powershell
& ./scripts/Build-Mobile.ps1 -Platform iOS -OpenIDE
```

A signed `.ipa` requires an Apple Developer account and signing profile. Android release builds similarly require a signing key.

## Architecture

The shipped simulation is a typed-array, height-field/cellular hybrid designed to avoid expensive grain-to-grain rigid-body collision. A 35k–77k-cell material field is automatically selected based on the device. Each cell represents liquid, trapped air, or one of four sand species. The renderer adds interface foam, granular shading, sparkle, glass glare and liquid caustics.

This is not a prerecorded animation. Every landscape is generated from the live state of the simulation.

## Validate the source

```powershell
& .\scripts\Test-SandScape.ps1
```

To run the optional Playwright interaction test as well:

```powershell
& .\scripts\Test-SandScape.ps1 -Browser
```

See `docs/BUILD-STATUS.md` for the exact validation record.

## Production hardening still requiring physical-device infrastructure

The source is complete and browser-tested, but final store binaries cannot be signed inside this environment. Before commercial release, run the included project on the target iPhone/Android matrix, profile 20-minute thermal behavior, generate store certificates, and complete App Store/Play Store privacy and metadata submissions.
