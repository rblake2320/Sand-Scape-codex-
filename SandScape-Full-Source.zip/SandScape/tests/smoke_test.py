"""SandScape browser smoke test.

Requires:
    python -m pip install playwright
    playwright install chromium

The test loads the static app in-memory so it can run in locked-down CI systems
that block localhost navigation.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "www"


def main() -> None:
    html = (WEB / "index.html").read_text(encoding="utf-8")
    html = html.replace('<link rel="stylesheet" href="./styles.css" />', "")
    html = html.replace('<script type="module" src="./sandscape.js"></script>', "")
    css = (WEB / "styles.css").read_text(encoding="utf-8")
    js = (WEB / "sandscape.js").read_text(encoding="utf-8")

    errors: list[str] = []
    with sync_playwright() as playwright:
        chromium = Path("/usr/bin/chromium")
        launch_args = {"headless": True}
        if chromium.exists():
            launch_args["executable_path"] = str(chromium)
            launch_args["args"] = ["--no-sandbox", "--disable-dev-shm-usage", "--disable-gpu"]
        browser = playwright.chromium.launch(**launch_args)
        page = browser.new_page(viewport={"width": 430, "height": 932})
        page.on("console", lambda message: errors.append(message.text) if message.type == "error" else None)
        page.on("pageerror", lambda error: errors.append(str(error)))
        page.set_content(html, wait_until="domcontentloaded")
        page.add_style_tag(content=css)
        page.add_script_tag(content=js, type="module")
        page.wait_for_function("window.sandscapeApp !== undefined")
        page.wait_for_timeout(1500)

        assert page.locator("#sandCanvas").count() == 1
        assert page.locator("#paletteDrawer").get_attribute("aria-hidden") == "true"
        assert page.evaluate("window.sandscapeApp.sim.cells.length > 30000")
        assert page.evaluate("Array.from(window.sandscapeApp.sim.cells).some(v => v >= 1 && v <= 4)")
        assert page.evaluate("Array.from(window.sandscapeApp.sim.cells).some(v => v === 5)")

        page.evaluate("window.sandscapeApp.openDrawer()")
        page.locator('[data-palette="desert"]').click()
        assert page.locator('[data-palette="desert"]').get_attribute("aria-checked") == "true"

        checksum = "cells => { let h = 2166136261 >>> 0; for (let i = 0; i < cells.length; i++) { h ^= (cells[i] + i); h = Math.imul(h, 16777619) >>> 0; } return h; }"
        before = page.evaluate(f"({checksum})(window.sandscapeApp.sim.cells)")
        page.locator("#flipButton").click()
        page.wait_for_timeout(150)
        after = page.evaluate(f"({checksum})(window.sandscapeApp.sim.cells)")
        assert before != after
        assert not errors, f"Browser errors: {errors}"
        browser.close()

    print("PASS: SandScape browser smoke test")


if __name__ == "__main__":
    main()
