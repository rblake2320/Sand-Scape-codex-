const MATERIAL = Object.freeze({
  LIQUID: 0,
  SAND_0: 1,
  SAND_1: 2,
  SAND_2: 3,
  SAND_3: 4,
  AIR: 5,
});

const PALETTES = [
  {
    id: 'ocean', name: 'Ocean', accent: '#8dc9ff', liquid: [16, 52, 78],
    background: [6, 20, 34], air: [184, 223, 246],
    sand: [[226, 244, 255], [112, 194, 243], [40, 130, 221], [20, 78, 164]],
  },
  {
    id: 'desert', name: 'Desert', accent: '#ffae51', liquid: [63, 48, 38],
    background: [28, 16, 12], air: [255, 222, 176],
    sand: [[255, 224, 164], [245, 157, 66], [213, 79, 40], [121, 36, 26]],
  },
  {
    id: 'aurum', name: 'Aurum', accent: '#f5cf66', liquid: [26, 24, 22],
    background: [8, 8, 8], air: [241, 226, 174],
    sand: [[255, 232, 146], [223, 177, 67], [129, 92, 20], [29, 27, 24]],
  },
  {
    id: 'orchid', name: 'Orchid', accent: '#d8a5ff', liquid: [48, 31, 61],
    background: [22, 12, 30], air: [232, 202, 244],
    sand: [[255, 203, 236], [219, 128, 216], [139, 79, 185], [70, 43, 118]],
  },
];

const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
const lerp = (a, b, t) => a + (b - a) * t;
const hypot = Math.hypot;

const safeStorage = {
  get(key) {
    try { return window.localStorage.getItem(key); } catch { return null; }
  },
  set(key, value) {
    try { window.localStorage.setItem(key, value); } catch { /* storage can be blocked in private/embedded contexts */ }
  },
};

class XorShift32 {
  constructor(seed = Date.now() | 0) { this.state = seed || 0x12345678; }
  nextInt() {
    let x = this.state | 0;
    x ^= x << 13; x ^= x >>> 17; x ^= x << 5;
    this.state = x | 0;
    return x >>> 0;
  }
  float() { return this.nextInt() / 4294967296; }
  range(min, max) { return min + (max - min) * this.float(); }
}

class SandSimulation {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false, desynchronized: true });
    this.bufferCanvas = document.createElement('canvas');
    this.bufferCtx = this.bufferCanvas.getContext('2d', { alpha: false });

    this.cols = 192;
    this.rows = 256;
    this.cells = null;
    this.nextCells = null;
    this.stamps = null;
    this.frameStamp = 1;
    this.imageData = null;
    this.rng = new XorShift32();

    this.gravity = { x: 0, y: 1 };
    this.targetGravity = { x: 0, y: 1 };
    this.viscosity = 0.70;
    this.airAmount = 0.54;
    this.palette = PALETTES[0];
    this.frameShape = 'circle';
    this.simAccumulator = 0;
    this.lastTime = performance.now();
    this.activity = 0;
    this.averageFrameMs = 16.7;
    this.qualityTier = 2;
    this.running = true;
    this.debug = false;
    this.lastRenderScale = 1;
    this.slowFrameCount = 0;
    this.qualityCooldownUntil = 0;

    this.configureResolution();
    this.resize();
    this.reset(true);
  }

  configureResolution() {
    const px = Math.max(screen.width || innerWidth, screen.height || innerHeight) * (devicePixelRatio || 1);
    const cores = navigator.hardwareConcurrency || 4;
    const memory = navigator.deviceMemory || 4;
    const coarse = matchMedia('(pointer: coarse)').matches;

    if ((cores >= 8 && memory >= 6 && px >= 1500) || !coarse) {
      this.qualityTier = 3;
      [this.cols, this.rows] = this.dimensionsForTier(3);
    } else if (cores >= 6 && memory >= 4) {
      this.qualityTier = 2;
      [this.cols, this.rows] = this.dimensionsForTier(2);
    } else {
      this.qualityTier = 1;
      [this.cols, this.rows] = this.dimensionsForTier(1);
    }

    this.allocate();
  }

  dimensionsForTier(tier) {
    if (tier >= 3) return [240, 320];
    if (tier === 2) return [208, 278];
    return [168, 224];
  }

  setQualityTier(tier, preserve = true) {
    const nextTier = clamp(Math.round(tier), 1, 3);
    if (nextTier === this.qualityTier && this.cells) return;

    const oldCells = this.cells;
    const oldCols = this.cols;
    const oldRows = this.rows;
    this.qualityTier = nextTier;
    [this.cols, this.rows] = this.dimensionsForTier(nextTier);
    this.allocate();

    if (preserve && oldCells && oldCols > 0 && oldRows > 0) {
      for (let y = 0; y < this.rows; y++) {
        const sy = Math.min(oldRows - 1, Math.floor((y + 0.5) * oldRows / this.rows));
        for (let x = 0; x < this.cols; x++) {
          if (!this.isInsideFrame(x, y)) continue;
          const sx = Math.min(oldCols - 1, Math.floor((x + 0.5) * oldCols / this.cols));
          this.cells[this.index(x, y)] = oldCells[sx + sy * oldCols];
        }
      }
    } else {
      this.reset(true);
    }

    this.resize();
    this.qualityCooldownUntil = performance.now() + 12000;
    window.dispatchEvent(new CustomEvent('sandscape-quality', { detail: { tier: nextTier } }));
  }

  monitorPerformance() {
    const now = performance.now();
    if (now < this.qualityCooldownUntil) return;
    if (this.averageFrameMs > 20.5 && this.qualityTier > 1) {
      this.slowFrameCount++;
      if (this.slowFrameCount > 150) {
        this.slowFrameCount = 0;
        this.setQualityTier(this.qualityTier - 1, true);
      }
    } else {
      this.slowFrameCount = Math.max(0, this.slowFrameCount - 2);
    }
  }

  allocate() {
    const size = this.cols * this.rows;
    this.cells = new Uint8Array(size);
    this.stamps = new Uint16Array(size);
    this.bufferCanvas.width = this.cols;
    this.bufferCanvas.height = this.rows;
    this.imageData = this.bufferCtx.createImageData(this.cols, this.rows);
  }

  resize() {
    const rect = this.canvas.getBoundingClientRect();
    const dpr = clamp(devicePixelRatio || 1, 1, 2.5);
    const w = Math.max(2, Math.round(rect.width * dpr));
    const h = Math.max(2, Math.round(rect.height * dpr));
    if (this.canvas.width !== w || this.canvas.height !== h) {
      this.canvas.width = w;
      this.canvas.height = h;
    }
  }

  setPalette(palette) { this.palette = palette; }
  setViscosity(value) { this.viscosity = clamp(value, 0.2, 0.93); }
  setAirAmount(value) { this.airAmount = clamp(value, 0.1, 0.88); }
  setFrameShape(shape) { this.frameShape = shape; }

  setGravity(x, y, immediate = false) {
    const length = hypot(x, y) || 1;
    this.targetGravity.x = x / length;
    this.targetGravity.y = y / length;
    if (immediate) {
      this.gravity.x = this.targetGravity.x;
      this.gravity.y = this.targetGravity.y;
    }
  }

  index(x, y) { return x + y * this.cols; }
  inBounds(x, y) { return x >= 0 && y >= 0 && x < this.cols && y < this.rows; }

  reset(initial = false) {
    this.cells.fill(MATERIAL.LIQUID);
    const { cols: w, rows: h, cells } = this;
    const g = this.gravity;
    const tangent = { x: -g.y, y: g.x };
    const center = { x: (w - 1) * 0.5, y: (h - 1) * 0.5 };
    const extent = Math.abs(tangent.x) * w + Math.abs(tangent.y) * h;
    const depthExtent = Math.abs(g.x) * w + Math.abs(g.y) * h;

    const upperStart = -depthExtent * 0.49;
    const upperEnd = -depthExtent * 0.10;
    const lowerStart = depthExtent * 0.29;
    const lowerEnd = depthExtent * 0.49;

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        if (!this.isInsideFrame(x, y)) continue;
        const rx = x - center.x;
        const ry = y - center.y;
        const d = rx * g.x + ry * g.y;
        const t = rx * tangent.x + ry * tangent.y;
        const waviness = Math.sin(t * 0.045) * 3 + Math.sin(t * 0.103 + 1.7) * 1.4;

        if (d >= upperStart && d < upperEnd + waviness) {
          const normalized = clamp((d - upperStart) / (upperEnd - upperStart), 0, 0.999);
          const layer = clamp(Math.floor(normalized * 4), 0, 3);
          cells[this.index(x, y)] = MATERIAL.SAND_0 + layer;
        } else if (d > lowerStart + waviness * 0.5 && d <= lowerEnd) {
          const normalized = clamp((d - lowerStart) / (lowerEnd - lowerStart), 0, 0.999);
          const layer = 3 - clamp(Math.floor(normalized * 4), 0, 3);
          cells[this.index(x, y)] = MATERIAL.SAND_0 + layer;
        }
      }
    }

    this.seedAirBarrier();
    this.seedBubbles();
    if (!initial) this.jostle(0.16);
  }

  isInsideFrame(x, y) {
    if (this.frameShape === 'rectangle') {
      return x > 2 && x < this.cols - 3 && y > 2 && y < this.rows - 3;
    }
    const nx = (x + 0.5) / this.cols * 2 - 1;
    const ny = (y + 0.5) / this.rows * 2 - 1;
    return nx * nx + ny * ny < 0.955;
  }

  seedAirBarrier() {
    const { cols: w, rows: h, cells } = this;
    const g = this.gravity;
    const tangent = { x: -g.y, y: g.x };
    const center = { x: (w - 1) * 0.5, y: (h - 1) * 0.5 };
    const depthExtent = Math.abs(g.x) * w + Math.abs(g.y) * h;
    const barrierDepth = -depthExtent * 0.075;
    const thickness = Math.round(3 + this.airAmount * 7);
    const gapCount = 1 + Math.floor((1 - this.airAmount) * 3);
    const gaps = [];
    for (let i = 0; i < gapCount; i++) {
      gaps.push(this.rng.range(-0.34, 0.34));
    }

    for (let y = 1; y < h - 1; y++) {
      for (let x = 1; x < w - 1; x++) {
        if (!this.isInsideFrame(x, y)) continue;
        const rx = x - center.x;
        const ry = y - center.y;
        const d = rx * g.x + ry * g.y;
        const tNorm = (rx * tangent.x + ry * tangent.y) / Math.max(w, h);
        const ripple = Math.sin(tNorm * 24 + 0.7) * 1.4;
        if (Math.abs(d - barrierDepth - ripple) <= thickness) {
          let isGap = false;
          for (const gap of gaps) {
            const gapWidth = 0.012 + (1 - this.airAmount) * 0.022;
            if (Math.abs(tNorm - gap) < gapWidth) { isGap = true; break; }
          }
          if (!isGap) {
            const idx = this.index(x, y);
            if (cells[idx] === MATERIAL.LIQUID) cells[idx] = MATERIAL.AIR;
          }
        }
      }
    }
  }

  seedBubbles() {
    const count = Math.floor(7 + this.airAmount * 14);
    for (let i = 0; i < count; i++) {
      const cx = this.rng.range(this.cols * 0.14, this.cols * 0.86);
      const cy = this.rng.range(this.rows * 0.28, this.rows * 0.68);
      const r = this.rng.range(1.2, 3.8) * (0.7 + this.airAmount * 0.6);
      for (let y = Math.floor(cy - r); y <= Math.ceil(cy + r); y++) {
        for (let x = Math.floor(cx - r); x <= Math.ceil(cx + r); x++) {
          if (!this.inBounds(x, y) || !this.isInsideFrame(x, y)) continue;
          const dx = x - cx, dy = y - cy;
          if (dx * dx + dy * dy <= r * r) {
            const idx = this.index(x, y);
            if (this.cells[idx] === MATERIAL.LIQUID) this.cells[idx] = MATERIAL.AIR;
          }
        }
      }
    }
  }

  flip() {
    const { cells, cols: w, rows: h } = this;
    for (let y = 0; y < Math.floor(h / 2); y++) {
      for (let x = 0; x < w; x++) {
        const a = this.index(x, y);
        const b = this.index(w - 1 - x, h - 1 - y);
        const tmp = cells[a]; cells[a] = cells[b]; cells[b] = tmp;
      }
    }
    if (h % 2 === 1) {
      const y = Math.floor(h / 2);
      for (let x = 0; x < Math.floor(w / 2); x++) {
        const a = this.index(x, y);
        const b = this.index(w - 1 - x, y);
        const tmp = cells[a]; cells[a] = cells[b]; cells[b] = tmp;
      }
    }
    this.jostle(0.24);
  }

  jostle(strength = 0.15) {
    const swaps = Math.floor(this.cells.length * strength);
    for (let i = 0; i < swaps; i++) {
      const x = 2 + (this.rng.nextInt() % (this.cols - 4));
      const y = 2 + (this.rng.nextInt() % (this.rows - 4));
      const nx = x + ((this.rng.nextInt() % 3) - 1);
      const ny = y + ((this.rng.nextInt() % 3) - 1);
      if (!this.inBounds(nx, ny)) continue;
      const a = this.index(x, y), b = this.index(nx, ny);
      if (this.cells[a] !== MATERIAL.LIQUID && this.cells[b] === MATERIAL.LIQUID) {
        this.cells[b] = this.cells[a]; this.cells[a] = MATERIAL.LIQUID;
      }
    }
  }

  disturb(normX, normY, radius = 0.075) {
    const cx = normX * this.cols;
    const cy = normY * this.rows;
    const r = Math.max(5, radius * Math.min(this.cols, this.rows));
    const candidates = [];
    for (let y = Math.max(1, Math.floor(cy - r)); y < Math.min(this.rows - 1, Math.ceil(cy + r)); y++) {
      for (let x = Math.max(1, Math.floor(cx - r)); x < Math.min(this.cols - 1, Math.ceil(cx + r)); x++) {
        const dx = x - cx, dy = y - cy;
        if (dx * dx + dy * dy > r * r) continue;
        const idx = this.index(x, y);
        if (this.cells[idx] >= MATERIAL.SAND_0 && this.cells[idx] <= MATERIAL.SAND_3) candidates.push(idx);
      }
    }
    for (let i = candidates.length - 1; i >= 0; i--) {
      const idx = candidates[i];
      const x = idx % this.cols, y = (idx / this.cols) | 0;
      const angle = this.rng.range(0, Math.PI * 2);
      const distance = this.rng.range(2, r * 0.7);
      const nx = Math.round(x + Math.cos(angle) * distance);
      const ny = Math.round(y + Math.sin(angle) * distance);
      if (!this.inBounds(nx, ny) || !this.isInsideFrame(nx, ny)) continue;
      const target = this.index(nx, ny);
      if (this.cells[target] === MATERIAL.LIQUID) {
        this.cells[target] = this.cells[idx];
        this.cells[idx] = MATERIAL.LIQUID;
      }
    }
  }

  gravityDirections(reverse = false) {
    let gx = reverse ? -this.gravity.x : this.gravity.x;
    let gy = reverse ? -this.gravity.y : this.gravity.y;
    const angle = Math.atan2(gy, gx);
    const octant = Math.round(angle / (Math.PI / 4));
    const dirs = [
      [1, 0], [1, 1], [0, 1], [-1, 1], [-1, 0], [-1, -1], [0, -1], [1, -1],
    ];
    const main = dirs[(octant + 8) % 8];
    const left = dirs[(octant + 7 + 8) % 8];
    const right = dirs[(octant + 1 + 8) % 8];
    const sideA = dirs[(octant + 6 + 8) % 8];
    const sideB = dirs[(octant + 2 + 8) % 8];
    return [main, this.rng.float() < 0.5 ? left : right, this.rng.float() < 0.5 ? right : left, sideA, sideB];
  }

  step(dt) {
    const smooth = 1 - Math.exp(-dt / 0.11);
    this.gravity.x = lerp(this.gravity.x, this.targetGravity.x, smooth);
    this.gravity.y = lerp(this.gravity.y, this.targetGravity.y, smooth);
    const gl = hypot(this.gravity.x, this.gravity.y) || 1;
    this.gravity.x /= gl; this.gravity.y /= gl;

    const targetSteps = this.qualityTier >= 3 ? 4 : this.qualityTier === 2 ? 3 : 2;
    const stepRate = lerp(34, 12, this.viscosity);
    this.simAccumulator += dt * stepRate;
    let steps = Math.min(targetSteps, Math.floor(this.simAccumulator));
    this.simAccumulator -= steps;
    if (steps <= 0 && this.activity > 0.02) steps = 1;

    let moved = 0;
    for (let i = 0; i < steps; i++) moved += this.simulateSubstep();
    this.activity = lerp(this.activity, moved / Math.max(1, this.cells.length * Math.max(1, steps)), 0.12);
  }

  simulateSubstep() {
    this.frameStamp = (this.frameStamp + 1) & 0xffff;
    if (this.frameStamp === 0) { this.stamps.fill(0); this.frameStamp = 1; }

    const dirs = this.gravityDirections(false);
    const airDirs = this.gravityDirections(true);
    const main = dirs[0];
    const yForward = main[1] >= 0;
    const xForward = main[0] >= 0;
    let moved = 0;

    const yStart = yForward ? this.rows - 2 : 1;
    const yEnd = yForward ? 0 : this.rows - 1;
    const yStep = yForward ? -1 : 1;
    const xStartBase = xForward ? this.cols - 2 : 1;
    const xEndBase = xForward ? 0 : this.cols - 1;
    const xStepBase = xForward ? -1 : 1;

    for (let y = yStart; y !== yEnd; y += yStep) {
      const reverseRow = (y & 1) === 0;
      const xStart = reverseRow ? (this.cols - 1 - xStartBase) : xStartBase;
      const xEnd = reverseRow ? (this.cols - 1 - xEndBase) : xEndBase;
      const xStep = reverseRow ? -xStepBase : xStepBase;
      for (let x = xStart; x !== xEnd; x += xStep) {
        const idx = this.index(x, y);
        if (this.stamps[idx] === this.frameStamp) continue;
        const mat = this.cells[idx];
        if (mat >= MATERIAL.SAND_0 && mat <= MATERIAL.SAND_3) {
          moved += this.updateSand(x, y, idx, mat, dirs);
        }
      }
    }

    // Air moves less frequently than sand to preserve coherent pressure pockets.
    if ((this.frameStamp & 1) === 0 || this.rng.float() < 0.35) {
      const ayStart = !yForward ? this.rows - 2 : 1;
      const ayEnd = !yForward ? 0 : this.rows - 1;
      const ayStep = !yForward ? -1 : 1;
      for (let y = ayStart; y !== ayEnd; y += ayStep) {
        for (let x = 1; x < this.cols - 1; x++) {
          const idx = this.index(x, y);
          if (this.cells[idx] === MATERIAL.AIR && this.stamps[idx] !== this.frameStamp) {
            moved += this.updateAir(x, y, idx, airDirs);
          }
        }
      }
    }

    return moved;
  }

  updateSand(x, y, idx, mat, dirs) {
    const density = mat - MATERIAL.SAND_0;
    const moveProbability = clamp((1 - this.viscosity) * (0.48 + density * 0.08), 0.035, 0.55);
    if (this.rng.float() > moveProbability) return 0;

    const candidates = [dirs[0], dirs[1], dirs[2]];
    if (this.rng.float() < 0.16) candidates.push(dirs[3], dirs[4]);

    for (const [dx, dy] of candidates) {
      const nx = x + dx, ny = y + dy;
      if (!this.inBounds(nx, ny) || !this.isInsideFrame(nx, ny)) continue;
      const ni = this.index(nx, ny);
      const target = this.cells[ni];
      if (target === MATERIAL.LIQUID) {
        this.cells[ni] = mat; this.cells[idx] = MATERIAL.LIQUID;
        this.stamps[ni] = this.frameStamp;
        return 1;
      }
      if (target >= MATERIAL.SAND_0 && target <= MATERIAL.SAND_3) {
        const targetDensity = target - MATERIAL.SAND_0;
        if (density > targetDensity && this.rng.float() < 0.055 + density * 0.015) {
          this.cells[ni] = mat; this.cells[idx] = target;
          this.stamps[ni] = this.frameStamp;
          return 1;
        }
      }
      // Air acts as a pressure barrier. Only rare leakage keeps channels alive.
      if (target === MATERIAL.AIR && this.rng.float() < 0.002 + (1 - this.airAmount) * 0.01) {
        this.cells[ni] = mat; this.cells[idx] = MATERIAL.AIR;
        this.stamps[ni] = this.frameStamp;
        return 1;
      }
    }
    return 0;
  }

  updateAir(x, y, idx, dirs) {
    if (this.rng.float() > 0.12 + (1 - this.viscosity) * 0.12) return 0;
    let best = null;
    let bestScore = -Infinity;
    for (let i = 0; i < Math.min(4, dirs.length); i++) {
      const [dx, dy] = dirs[i];
      const nx = x + dx, ny = y + dy;
      if (!this.inBounds(nx, ny) || !this.isInsideFrame(nx, ny)) continue;
      const ni = this.index(nx, ny);
      const target = this.cells[ni];
      if (target !== MATERIAL.LIQUID && !(target >= MATERIAL.SAND_0 && target <= MATERIAL.SAND_3)) continue;
      const cohesion = this.countNeighbors(nx, ny, MATERIAL.AIR);
      let score = (i === 0 ? 2.4 : 1.0) + cohesion * 0.9 + this.rng.float();
      if (target !== MATERIAL.LIQUID) score -= 2.2;
      if (score > bestScore) { bestScore = score; best = [ni, target]; }
    }
    if (!best) return 0;
    const [ni, target] = best;
    if (target === MATERIAL.LIQUID || this.rng.float() < 0.045) {
      this.cells[ni] = MATERIAL.AIR;
      this.cells[idx] = target;
      this.stamps[ni] = this.frameStamp;
      return 1;
    }
    return 0;
  }

  countNeighbors(x, y, material) {
    let count = 0;
    for (let oy = -1; oy <= 1; oy++) {
      for (let ox = -1; ox <= 1; ox++) {
        if (ox === 0 && oy === 0) continue;
        const nx = x + ox, ny = y + oy;
        if (this.inBounds(nx, ny) && this.cells[this.index(nx, ny)] === material) count++;
      }
    }
    return count;
  }

  render() {
    const { cols: w, rows: h, cells, imageData } = this;
    const p = this.palette;
    const data = imageData.data;
    const lightX = -0.42, lightY = -0.72;
    let o = 0;

    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++, o += 4) {
        if (!this.isInsideFrame(x, y)) {
          data[o] = 7; data[o + 1] = 9; data[o + 2] = 13; data[o + 3] = 255;
          continue;
        }
        const idx = this.index(x, y);
        const mat = cells[idx];
        const vignette = 1 - 0.20 * Math.pow(hypot(x / w - 0.5, y / h - 0.5) * 1.7, 1.7);
        const caustic = 0.96 + 0.04 * Math.sin(x * 0.055 + y * 0.021 + performance.now() * 0.00025);

        let r, g, b;
        if (mat === MATERIAL.LIQUID) {
          const depth = y / h;
          const shimmer = 0.94 + 0.06 * Math.sin(x * 0.08 + y * 0.025);
          r = lerp(p.liquid[0], p.background[0], depth * 0.42) * shimmer;
          g = lerp(p.liquid[1], p.background[1], depth * 0.42) * shimmer;
          b = lerp(p.liquid[2], p.background[2], depth * 0.42) * shimmer;
        } else if (mat === MATERIAL.AIR) {
          const edge = this.isInterface(x, y, MATERIAL.AIR);
          const brightness = edge ? 0.76 : 0.34;
          r = lerp(p.liquid[0], p.air[0], brightness);
          g = lerp(p.liquid[1], p.air[1], brightness);
          b = lerp(p.liquid[2], p.air[2], brightness);
          if (!edge) { r *= .72; g *= .76; b *= .80; }
        } else {
          const sandIndex = mat - MATERIAL.SAND_0;
          const color = p.sand[sandIndex];
          const edgeX = this.sampleSolid(x - 1, y) - this.sampleSolid(x + 1, y);
          const edgeY = this.sampleSolid(x, y - 1) - this.sampleSolid(x, y + 1);
          const light = clamp(0.82 + (edgeX * lightX + edgeY * lightY) * 0.095, 0.64, 1.16);
          const grain = 0.90 + ((x * 73856093 ^ y * 19349663 ^ mat * 83492791) & 15) / 120;
          const sparkle = (((x * 928371 + y * 364479 + mat * 97) >>> 0) % 997 === 0) ? 1.48 : 1;
          r = color[0] * light * grain * sparkle;
          g = color[1] * light * grain * sparkle;
          b = color[2] * light * grain * sparkle;

          if (this.isFoamInterface(x, y)) {
            r = lerp(r, 255, .28); g = lerp(g, 250, .28); b = lerp(b, 238, .28);
          }
        }

        const final = vignette * caustic;
        data[o] = clamp(r * final, 0, 255);
        data[o + 1] = clamp(g * final, 0, 255);
        data[o + 2] = clamp(b * final, 0, 255);
        data[o + 3] = 255;
      }
    }

    this.bufferCtx.putImageData(imageData, 0, 0);
    this.ctx.imageSmoothingEnabled = true;
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.drawImage(this.bufferCanvas, 0, 0, this.canvas.width, this.canvas.height);

    // Soft refraction bands and suspended micro-particles.
    this.ctx.save();
    this.ctx.globalCompositeOperation = 'screen';
    const grad = this.ctx.createLinearGradient(0, 0, this.canvas.width, this.canvas.height);
    grad.addColorStop(0, 'rgba(255,255,255,.035)');
    grad.addColorStop(.42, 'rgba(255,255,255,0)');
    grad.addColorStop(.78, 'rgba(255,255,255,.018)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    this.ctx.fillStyle = grad;
    this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);
    this.ctx.restore();

    if (this.debug) {
      this.ctx.fillStyle = 'rgba(0,0,0,.55)';
      this.ctx.fillRect(8, 8, 170, 50);
      this.ctx.fillStyle = '#fff';
      this.ctx.font = `${12 * (devicePixelRatio || 1)}px monospace`;
      this.ctx.fillText(`${w}×${h}  ${this.averageFrameMs.toFixed(1)}ms`, 14, 28);
    }
  }

  sampleSolid(x, y) {
    if (!this.inBounds(x, y)) return 1;
    const m = this.cells[this.index(x, y)];
    return (m >= MATERIAL.SAND_0 && m <= MATERIAL.SAND_3) ? 1 : 0;
  }

  isInterface(x, y, material) {
    for (let oy = -1; oy <= 1; oy++) {
      for (let ox = -1; ox <= 1; ox++) {
        if (ox === 0 && oy === 0) continue;
        const nx = x + ox, ny = y + oy;
        if (this.inBounds(nx, ny) && this.cells[this.index(nx, ny)] !== material) return true;
      }
    }
    return false;
  }

  isFoamInterface(x, y) {
    const idx = this.index(x, y);
    const mat = this.cells[idx];
    if (mat < MATERIAL.SAND_0 || mat > MATERIAL.SAND_3) return false;
    let air = false, liquid = false;
    for (let oy = -1; oy <= 1; oy++) {
      for (let ox = -1; ox <= 1; ox++) {
        if (ox === 0 && oy === 0) continue;
        const nx = x + ox, ny = y + oy;
        if (!this.inBounds(nx, ny)) continue;
        const m = this.cells[this.index(nx, ny)];
        if (m === MATERIAL.AIR) air = true;
        if (m === MATERIAL.LIQUID) liquid = true;
      }
    }
    return air || (liquid && ((x * 17 + y * 31) % 23 === 0));
  }

  tick = (time) => {
    if (!this.running) return;
    const dt = clamp((time - this.lastTime) / 1000, 0.001, 0.05);
    this.lastTime = time;
    const start = performance.now();
    this.step(dt);
    this.render();
    const frameMs = performance.now() - start;
    this.averageFrameMs = lerp(this.averageFrameMs, frameMs, 0.035);
    this.monitorPerformance();
    requestAnimationFrame(this.tick);
  };

  start() {
    this.lastTime = performance.now();
    requestAnimationFrame(this.tick);
  }

  capture() {
    const output = document.createElement('canvas');
    const size = 1400;
    output.width = size; output.height = this.frameShape === 'circle' ? size : Math.round(size * 1.35);
    const ctx = output.getContext('2d');
    ctx.fillStyle = '#080b11'; ctx.fillRect(0, 0, output.width, output.height);
    ctx.save();
    if (this.frameShape === 'circle') {
      ctx.beginPath(); ctx.arc(output.width / 2, output.height / 2, output.width * .46, 0, Math.PI * 2); ctx.clip();
    } else {
      const r = 52; const x = 55, y = 55, w = output.width - 110, h = output.height - 110;
      ctx.beginPath();
      ctx.roundRect(x, y, w, h, r); ctx.clip();
    }
    ctx.drawImage(this.canvas, 0, 0, output.width, output.height);
    ctx.restore();
    ctx.strokeStyle = '#171b22'; ctx.lineWidth = 38;
    if (this.frameShape === 'circle') {
      ctx.beginPath(); ctx.arc(output.width / 2, output.height / 2, output.width * .46, 0, Math.PI * 2); ctx.stroke();
    } else {
      ctx.beginPath(); ctx.roundRect(55, 55, output.width - 110, output.height - 110, 52); ctx.stroke();
    }
    ctx.fillStyle = 'rgba(255,255,255,.78)'; ctx.font = '600 30px sans-serif'; ctx.fillText('SandScape', 72, output.height - 54);
    const link = document.createElement('a');
    link.download = `SandScape-${new Date().toISOString().replace(/[:.]/g, '-')}.png`;
    link.href = output.toDataURL('image/png');
    link.click();
  }
}

class MotionController {
  constructor(simulation, onStatus) {
    this.simulation = simulation;
    this.onStatus = onStatus;
    this.enabled = false;
    this.lastShake = 0;
    this.motionBound = this.onDeviceMotion.bind(this);
    this.orientationBound = this.onOrientation.bind(this);
  }

  async enable() {
    try {
      if (typeof DeviceOrientationEvent !== 'undefined' && typeof DeviceOrientationEvent.requestPermission === 'function') {
        const permission = await DeviceOrientationEvent.requestPermission();
        if (permission !== 'granted') throw new Error('Motion permission was not granted.');
      }
      if (typeof DeviceMotionEvent !== 'undefined' && typeof DeviceMotionEvent.requestPermission === 'function') {
        const permission = await DeviceMotionEvent.requestPermission();
        if (permission !== 'granted') throw new Error('Motion permission was not granted.');
      }
      window.addEventListener('deviceorientation', this.orientationBound, true);
      window.addEventListener('devicemotion', this.motionBound, true);
      this.enabled = true;
      this.onStatus('Tilt enabled', true);
    } catch (error) {
      this.onStatus(error?.message || 'Tilt unavailable; drag the frame instead.', false);
    }
  }

  onOrientation(event) {
    if (event.beta == null || event.gamma == null) return;
    const beta = clamp(event.beta, -90, 90) * Math.PI / 180;
    const gamma = clamp(event.gamma, -90, 90) * Math.PI / 180;
    let x = Math.sin(gamma);
    let y = Math.sin(beta) * Math.cos(gamma);

    const angle = screen.orientation?.angle ?? window.orientation ?? 0;
    if (angle === 90 || angle === -270) [x, y] = [y, -x];
    else if (angle === 270 || angle === -90) [x, y] = [-y, x];
    else if (Math.abs(angle) === 180) { x = -x; y = -y; }

    // Keep a small downward bias while the phone lies close to flat.
    const magnitude = hypot(x, y);
    if (magnitude < 0.12) y += 0.12;
    this.simulation.setGravity(x, y);
  }

  onDeviceMotion(event) {
    const a = event.acceleration;
    if (!a || a.x == null || a.y == null || a.z == null) return;
    const magnitude = hypot(a.x, a.y, a.z);
    const now = performance.now();
    if (magnitude > 19 && now - this.lastShake > 1200) {
      this.lastShake = now;
      this.simulation.flip();
      this.onStatus('Sand flipped', true);
    }
  }
}

class SandScapeApp {
  constructor() {
    this.canvas = document.querySelector('#sandCanvas');
    this.frame = document.querySelector('#frameShell');
    this.drawer = document.querySelector('#paletteDrawer');
    this.scrim = document.querySelector('#drawerScrim');
    this.holdIndicator = document.querySelector('#holdIndicator');
    this.toast = document.querySelector('#toast');
    this.motionButton = document.querySelector('#motionButton');
    this.motionDrawerButton = document.querySelector('#motionDrawerButton');
    this.hint = document.querySelector('#hint');

    this.sim = new SandSimulation(this.canvas);
    this.motion = new MotionController(this.sim, (message, success) => this.handleMotionStatus(message, success));
    this.longPressTimer = null;
    this.pointerStart = null;
    this.dragging = false;
    this.toastTimer = null;
    this.selectedPalette = PALETTES[0].id;

    this.renderPalettes();
    this.bindEvents();
    this.applyPalette(PALETTES[0]);
    this.sim.start();

    setTimeout(() => { this.hint.style.opacity = '.35'; }, 7000);
  }

  renderPalettes() {
    const list = document.querySelector('#paletteList');
    list.innerHTML = '';
    for (const palette of PALETTES) {
      const button = document.createElement('button');
      button.className = 'palette-card';
      button.type = 'button';
      button.role = 'radio';
      button.dataset.palette = palette.id;
      button.setAttribute('aria-checked', palette.id === this.selectedPalette ? 'true' : 'false');
      button.innerHTML = `<span class="palette-swatch"></span><span class="palette-name">${palette.name}</span>`;
      const swatch = button.querySelector('.palette-swatch');
      swatch.style.background = `linear-gradient(135deg, ${palette.sand.map(c => `rgb(${c.join(',')})`).join(', ')})`;
      button.addEventListener('click', () => this.applyPalette(palette));
      list.appendChild(button);
    }
  }

  applyPalette(palette) {
    this.selectedPalette = palette.id;
    this.sim.setPalette(palette);
    document.documentElement.style.setProperty('--accent', palette.accent);
    document.querySelector('.ambient-a').style.background = `rgb(${palette.sand[3].join(',')})`;
    document.querySelector('.ambient-b').style.background = `rgb(${palette.sand[0].join(',')})`;
    for (const button of document.querySelectorAll('.palette-card')) {
      button.setAttribute('aria-checked', button.dataset.palette === palette.id ? 'true' : 'false');
    }
    safeStorage.set('sandscape.palette', palette.id);
  }

  bindEvents() {
    window.addEventListener('resize', () => this.sim.resize(), { passive: true });
    window.addEventListener('sandscape-quality', event => {
      const label = event.detail?.tier === 1 ? 'battery' : 'balanced';
      this.showToast(`Performance adjusted · ${label} mode`);
    });
    document.addEventListener('visibilitychange', () => {
      this.sim.running = !document.hidden;
      if (!document.hidden) this.sim.start();
    });

    this.motionButton.addEventListener('click', () => this.motion.enable());
    this.motionDrawerButton.addEventListener('click', () => this.motion.enable());
    document.querySelector('#closeDrawer').addEventListener('click', () => this.closeDrawer());
    this.scrim.addEventListener('click', () => this.closeDrawer());
    document.querySelector('#flipButton').addEventListener('click', () => {
      this.sim.flip(); this.showToast('Sand flipped');
    });
    document.querySelector('#captureButton').addEventListener('click', () => {
      this.sim.capture(); this.showToast('Scene saved');
    });
    document.querySelector('#shapeButton').addEventListener('click', (event) => {
      const rectangle = this.frame.classList.contains('circle');
      this.frame.classList.toggle('circle', !rectangle);
      this.frame.classList.toggle('rectangle', rectangle);
      event.currentTarget.textContent = rectangle ? 'Circle frame' : 'Rectangle frame';
      this.sim.setFrameShape(rectangle ? 'rectangle' : 'circle');
      setTimeout(() => { this.sim.resize(); this.sim.reset(); }, 440);
    });
    document.querySelector('#viscosityInput').addEventListener('input', (event) => {
      this.sim.setViscosity(Number(event.target.value) / 100);
    });
    document.querySelector('#airInput').addEventListener('input', (event) => {
      this.sim.setAirAmount(Number(event.target.value) / 100);
    });

    this.frame.addEventListener('pointerdown', (event) => this.onPointerDown(event));
    this.frame.addEventListener('pointermove', (event) => this.onPointerMove(event));
    this.frame.addEventListener('pointerup', (event) => this.onPointerUp(event));
    this.frame.addEventListener('pointercancel', () => this.cancelPointer());
    this.frame.addEventListener('contextmenu', event => event.preventDefault());

    window.addEventListener('keydown', (event) => {
      const map = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] };
      if (map[event.key]) { event.preventDefault(); this.sim.setGravity(...map[event.key]); }
      if (event.key.toLowerCase() === 'f') this.sim.flip();
      if (event.key.toLowerCase() === 'p') this.openDrawer();
      if (event.key.toLowerCase() === 'd') this.sim.debug = !this.sim.debug;
    });

    const saved = safeStorage.get('sandscape.palette');
    const palette = PALETTES.find(p => p.id === saved);
    if (palette) this.applyPalette(palette);
  }

  onPointerDown(event) {
    this.frame.setPointerCapture?.(event.pointerId);
    const rect = this.frame.getBoundingClientRect();
    this.pointerStart = { x: event.clientX, y: event.clientY, time: performance.now(), pointerId: event.pointerId };
    this.dragging = false;
    this.holdIndicator.style.left = `${event.clientX - rect.left}px`;
    this.holdIndicator.style.top = `${event.clientY - rect.top}px`;
    this.holdIndicator.classList.add('active');
    this.longPressTimer = setTimeout(() => {
      this.longPressTimer = null;
      this.holdIndicator.classList.remove('active');
      this.openDrawer();
      navigator.vibrate?.(22);
    }, 650);
  }

  onPointerMove(event) {
    if (!this.pointerStart) return;
    const dx = event.clientX - this.pointerStart.x;
    const dy = event.clientY - this.pointerStart.y;
    const distance = hypot(dx, dy);
    if (distance > 8) {
      this.dragging = true;
      this.cancelLongPress();
      const rect = this.frame.getBoundingClientRect();
      const centerX = rect.left + rect.width / 2;
      const centerY = rect.top + rect.height / 2;
      this.sim.setGravity(event.clientX - centerX, event.clientY - centerY);
    }
  }

  onPointerUp(event) {
    if (!this.pointerStart) return;
    const wasLongPress = this.longPressTimer == null && this.drawer.classList.contains('open');
    const elapsed = performance.now() - this.pointerStart.time;
    const rect = this.frame.getBoundingClientRect();
    this.cancelLongPress();
    if (!this.dragging && !wasLongPress && elapsed < 620) {
      const x = clamp((event.clientX - rect.left) / rect.width, 0, 1);
      const y = clamp((event.clientY - rect.top) / rect.height, 0, 1);
      this.sim.disturb(x, y);
      navigator.vibrate?.(8);
    }
    this.pointerStart = null;
    this.dragging = false;
  }

  cancelPointer() {
    this.cancelLongPress();
    this.pointerStart = null;
    this.dragging = false;
  }

  cancelLongPress() {
    if (this.longPressTimer) clearTimeout(this.longPressTimer);
    this.longPressTimer = null;
    this.holdIndicator.classList.remove('active');
  }

  openDrawer() {
    this.drawer.classList.add('open');
    this.scrim.classList.add('open');
    this.drawer.setAttribute('aria-hidden', 'false');
    this.scrim.setAttribute('aria-hidden', 'false');
  }

  closeDrawer() {
    this.drawer.classList.remove('open');
    this.scrim.classList.remove('open');
    this.drawer.setAttribute('aria-hidden', 'true');
    this.scrim.setAttribute('aria-hidden', 'true');
  }

  handleMotionStatus(message, success) {
    this.showToast(message);
    if (success) {
      this.motionButton.textContent = 'Tilt active';
      this.motionDrawerButton.textContent = 'Tilt active';
      this.motionButton.classList.add('active');
      this.motionDrawerButton.classList.add('active');
    }
  }

  showToast(message) {
    clearTimeout(this.toastTimer);
    this.toast.textContent = message;
    this.toast.classList.add('show');
    this.toastTimer = setTimeout(() => this.toast.classList.remove('show'), 2200);
  }
}

window.sandscapeApp = new SandScapeApp();

if ('serviceWorker' in navigator && location.protocol !== 'file:') {
  window.addEventListener('load', () => navigator.serviceWorker.register('./sw.js').catch(() => {}));
}
