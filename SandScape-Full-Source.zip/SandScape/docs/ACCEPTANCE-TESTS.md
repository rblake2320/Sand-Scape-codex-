# SandScape acceptance tests

1. Launch in portrait and landscape; frame remains fully visible and clipped correctly.
2. On iOS, tap Enable tilt and grant motion permission. Gravity follows phone orientation without hand-tremor jitter.
3. On Android, enable tilt and verify orientation updates without a permission dialog where the browser does not require one.
4. Observe upper sand held by an air interface, with one or more narrow trickle paths.
5. Wait for settling; visible colored striation must remain.
6. Tap three different points; disturbance remains local.
7. Shake once; frame flips once and does not repeatedly retrigger for at least 1.2 seconds.
8. Long press; drawer opens. Select each palette and verify immediate recoloring.
9. Change Flow and Air controls; verify perceptible behavior changes.
10. Switch circular/rectangle frames and verify the simulation resets inside the correct boundary.
11. Save scene and verify PNG creation.
12. Install as PWA, enter airplane mode, and relaunch successfully.
13. Run for 20 minutes on iPhone 12 / Pixel 6 class devices and record average frame time and thermal state.
