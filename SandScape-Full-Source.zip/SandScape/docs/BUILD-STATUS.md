# Build status — 2026-07-13

## Completed

- Functional offline PWA implementation
- Adaptive 35k–77k-cell live sand/air/liquid simulation
- Four stratified sand materials and four selectable palettes
- Device-orientation gravity, smoothing, shake-to-flip, touch disturbance and desktop fallback controls
- Circular and rectangular glass-frame presentation
- Flow and trapped-air controls, screenshot export and offline service worker
- Capacitor 8.4.1 Android native project generated and synchronized
- Capacitor 8.4.1 iOS Xcode project generated and synchronized using Swift Package Manager
- Native Android/iOS app icons and splash artwork generated
- Android and iOS web assets synchronized into their native projects

## Validation performed

- `node --check www/sandscape.js`: PASS
- JSON validation for package, Capacitor configuration and web manifest: PASS
- `npm audit` (production and full dependency tree): 0 vulnerabilities
- Headless Chromium/Playwright functional smoke test: PASS
- Browser console/page errors during smoke test: none
- Palette selection, drawer operation and flip-state mutation: PASS
- Capacitor dependency alignment: 8.4.1 across core, CLI, Android and iOS
- `npx cap doctor`: Android project healthy; Xcode unavailable in the Linux build environment
- Headless software-rendered diagnostic run at 240×320 simulation resolution averaged approximately 17.5 ms per simulation/render pass. This is a development diagnostic, not a physical-device performance certification.

## External release steps that cannot be completed without owner credentials/hardware

- A signed iOS `.ipa` requires macOS, Xcode 26+, an Apple Developer team and signing profile.
- A signed Android `.aab`/release `.apk` requires Android SDK 36 and the owner's protected signing key.
- The iPhone 12 / Android-equivalent 20-minute thermal and sensor tests require physical devices.
- App Store Connect and Google Play submissions require the owner's store accounts, privacy declarations and listing approvals.

No signing keys, certificates, account credentials or fabricated device benchmark results are included.
